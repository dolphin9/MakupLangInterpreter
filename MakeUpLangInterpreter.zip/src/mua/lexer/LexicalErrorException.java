package mua.lexer;

public class LexicalErrorException extends Exception {
    // TODO: 17-9-28 To be implemented.
}

class BracketNotPairedException extends LexicalErrorException {
    // TODO: 17-9-28 To be implemented.
}

